
# Shrikant AI Configuration

BOT_TOKEN = "9175090730:AAFLm2dg02w4s-ny3vSwd6cv0I7B-udJgD8"
