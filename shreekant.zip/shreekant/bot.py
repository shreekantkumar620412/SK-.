
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters
)

# अपना Telegram Token यहाँ डालें
BOT_TOKEN = "9175090730:AAF76M9vUoUzTx6zjF6SmNOiOcZp61R785E"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 Welcome to Shrikant AI Assistant!\n\n"
        "Namaste! Hindi aur English mein baat karein.\n\n"
        "/about - About AI\n"
        "/help - Help Menu\n"
        "/services - Our Services\n"
        "/contact - Contact Support"
    )


async def about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 I am Shrikant AI Assistant!\n"
        "I support Hindi and English."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📚 HELP MENU\n\n"
        "/start - Start Bot\n"
        "/about - About AI\n"
        "/help - Help Menu\n"
        "/services - Services\n"
        "/contact - Contact"
    )


async def services(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🛠️ SHRIKANT AI SERVICES\n\n"
        "1. Electrical Services\n"
        "2. Online Services\n"
        "3. Electronic Services\n"
        "4. Computer Help\n"
        "5. Customer Support"
    )


async def contact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📞 SHRIKANT AI SUPPORT\n\n"
        "Please send your question here.\n"
        "Language: Hindi & English"
    )


async def reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 Your message received!\n"
        "Real AI connection is coming soon."
    )


def main():
    if "PASTE_YOUR_TOKEN" in BOT_TOKEN:
        print("Please add your Telegram Bot Token!")
        return

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("about", about))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("services", services))
    app.add_handler(CommandHandler("contact", contact))

    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, reply)
    )

    print("Shrikant AI Bot is Running!")

    app.run_polling()


if __name__ == "__main__":
    main()
